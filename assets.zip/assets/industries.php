 <!DOCTYPE html>
<html>
<head>
     <title>Industries</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- Favicon -->   
    <link rel="icon" type="image/png" sizes="32x32" href="images/favicon.png">    
    <!-- css -->
    <link href="css/bootstrap.min.css" rel="stylesheet" />
    <link href="css/main.css" rel="stylesheet" />
    <link href="css/uikit.min.css" rel="stylesheet" />
    <link href="css/ui.css" rel="stylesheet" />
    <link href="css/font-awesome.css" rel="stylesheet" />
    <link href="css/owl.carousel.css" rel="stylesheet" />    
    <link href="css/animate.css" rel="stylesheet" />
    <!-- fonts -->
    <link href="https://fonts.googleapis.com/css?family=Rubik:300,300i,400,400i,500,500i,700,700i,900,900i" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Lato:100i,300,300i,400,400i,700,700i,900,900i" rel="stylesheet">
</head>
<body>
     <div class="topBand">
        <div class="container">
            <div class="row">
                <div class="col-sm-8">
                    <ul class="list-inline list_social">
                        <li class="list-inline-item"><a href="tel:9820731115"><i class="fa fa-phone"></i> &nbsp; Call us (+91) 9820731115</a></li>
                        <li class="list-inline-item"><a href="mailto:phenixlingualsolutions@gmail.com"><i class="fa fa-envelope"></i>&nbsp;phenixlingualsolutions@gmail.com</a></li>
                    </ul>
                </div>
                <div class="col-sm-4">
                    <ul class="list-inline list_social float-right social_div">
                        <li class="list-inline-item"><a href="#"><i class="fa fa-facebook"></i></a></li>
                        <li class="list-inline-item"><a href="#"><i class="fa fa-twitter"></i></a></li>
                        <li class="list-inline-item"><a href="#"><i class="fa fa-linkedin"></i></a></li>
                        <li class="list-inline-item"><a href="#"><i class="fa fa-instagram"></i></a></li>
                        <li class="list-inline-item"><a href="#"><i class="fa fa-youtube"></i></a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <header>
        <div uk-sticky="animation: uk-animation-slide-top; sel-target: .uk-navbar-container; cls-active: uk-navbar-sticky; cls-inactive: uk-navbar-transparent uk-light; top: 200">

            <nav class="navbar navbar-expand-lg navbar-light bg-light">
                <div class="container">
                    <a class="navbar-brand" href="index.html">
                       <img src="images/Logo.jpeg" alt="logo" height="50" width="50" />
                    </a>
                    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon"></span>
                    </button>
                    <div class="collapse navbar-collapse" id="navbarNav">
                        <ul class="navbar-nav ml-auto">
                            <li class="nav-item active">
                                <div class="uk-inline drop_links">
                                <a class="nav-link" href="industries.php"> Industries &nbsp;<i class="fa fa-angle-down"></i></a>
                                 <div uk-dropdown>
                                    <ul class="list-unstyled">
                                        <li class="p-l-10 f-14">
                                            Engineering
                                        </li>
                                       <li class="p-l-10 f-14">
                                             Healthcare
                                        </li>
                                        <li class="p-l-10 f-14">
                                            Construction/Real Estate
                                        </li>
                                        <li class="p-l-10 f-14">
                                            Defence
                                        </li>
                                        <li class="p-l-10 f-14">
                                            Hotels & Hospitals
                                        </li>
                                        <li class="p-l-10 f-14">
                                            Banking
                                        </li>
                                        <li class="p-l-10 f-14">
                                            Legal
                                        </li>
                                         <li class="p-l-10 f-14">
                                            Travel
                                        </li>
                                       <li class="p-l-10 f-14">
                                            Education
                                        </li>
                                       <li class="p-l-10 f-14">
                                            IT
                                        </li>
                                    </ul>
                                 </div>
                                </div>
                            </li>
                            <li class="nav-item">
                                   <div class="uk-inline drop_links">
                                <a class="nav-link" href="#">Translation & Interpretation Services(T&I) &nbsp;<i class="fa fa-angle-down"></i></a>
                                 <div uk-dropdown>
                                    <ul class="list-unstyled">
                                         <li class="p-l-10 f-14">
                                            Technical T&I
                                        </li>
                                       <li class="p-l-10 f-14">
                                            Medical T&I
                                        </li>
                                        <li class="p-l-10 f-14">
                                            Legal T&I 
                                        </li>
                                         <li class="p-l-10 f-14">
                                            Marketing T&I
                                        </li>
                                        <li class="p-l-10 f-14">
                                            Financial T&I
                                        </li>
                                        <li class="p-l-10 f-14">
                                            Document T&I
                                        </li>
                                        <li class="p-l-10 f-14">
                                            Literary T&I
                                        </li>
                                        <li class="p-l-10 f-14">
                                            Business T&I
                                        </li>
                                        <li class="p-l-10 f-14">
                                            Travel T&I
                                        </li>
                                        <li class="p-l-10 f-14">
                                            Banking T&I
                                        </li>
                                        <li class="p-l-10 f-14">
                                            Transcriptions T&I
                                        </li>
                                    </ul>
                                 </div>
                                </div>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="#">How we work?</a>
                            </li>
                           
                            <li class="nav-item">
                                <a class="nav-link" href="#">About us</a>
                            </li>
                        </ul>
                    </div>
                </div>
            </nav>
        </div>
    </header>
    
<div class="page_head ecommerce">
     <div class="container">
        <div class="row">
            <div class="col-xl-12">
                <h1>Industries</h1>
                <ul class="uk-breadcrumb">
                    <li><a href="index.php">Home</a></li>
                    <li><span>Industries</span></li>
                </ul>
            </div>
        </div>
    </div>
</div>
<div class="inner_space">
     <div class="container">
        <div class="row">
            <div class="col-xl-8">
                <h3><strong> Technical T&I </strong></h4>
                <p class="justify">We combine the art and science of interpreting and translating technical documents to construct 
                procedural documents across French, Chinese, Japanese, German and English. These include 
                proposals, technical literature, reports, instructions, reviews, surveys, technical guides, agendas, 
                contracts, advertisements, press releases, handbooks, etc.  </p>
                
                 <h3><strong> Medical T&I </strong></h4>
                <p class="justify">We extract, interpret, translate, edit and proofread all medical literature, including medical books, 
                medical transcripts, healthcare documents and brochures, documents, research papers, reports, and 
                all pharmaceutical documents across French, Chinese, Japanese, German and English. </p>
                
                 <h3><strong> Legal T&I </strong></h4>
                <p class="justify">Translation of legal documents is heavily dependent on cultural interpretation and understanding. 
                We assess and thoroughly analyse linguistic structures to ensure there is no scope for 
                misinterpretation of legal documents in the translation process. We translate all legal documents 
                including MoUs, NDAs, operational agreements, employment and vendor contracts, bylaw 
                documents, apostilles, policies, T&Cs, business plans, etc., across French, Chinese, Japanese, German 
                and English.  </p>
                
                 <h3><strong> Marketing T&I </strong></h4>
                <p class="justify">Persuasiveness and creativity are what define marketing communication. Retaining the flavour of the 
                communication and making it relevant to the cultural sensitivity of the audience of the translated 
                work is our speciality. We can help you expand your marketing efforts via our translation services 
                across French, Chinese, Japanese, German and English of all marketing literature, including 
                brochures, advertisements, marketing strategies, content, reports, agreements, etc. </p>
                
                <h3><strong> Financial T&I </strong></h4>
                <p class="justify">We convert all financial statements, balance sheets, audit reports, documents, financial records and 
                reports between French, Chinese, Japanese, German and English via accurate interpretation and 
                translation. Our translators comprise of linguistic experts who understand financial terminology. This 
                ensures accurate interpretation and translation of your financial documents.</p>
                
                <h3><strong> Document T&I </strong></h4>
                <p class="justify">Our linguistic expertise ensures all your documents, including manuals, websites, sub-titles, videos, 
                emails, audio documents, letters and more are interpreted and translated error-free, and with 
                accuracy. We translate documents between French, Chinese, Japanese, German and English.</p>
                
                <h3><strong> Literary T&I </strong></h4>
                <p class="justify">The beauty of literary translation lies in the challenge of interpreting the essence of the writing and 
                translating it by retaining the essence of the original and conveying it effectively in the translated 
                language. Our T&I team has extensive experience in translating literary documents, including stories, 
                books, academic literature, essays, journals, etc. between French, Chinese, Japanese, German and English.</p>
                
            </div>
             <div class="col-xl-4">
                <div class="uk-card uk-card-default">
                    <div class="uk-card-header bg_expand">
                        <div class="uk-grid-small uk-flex-middle" uk-grid>                            
                            <div class="uk-width-expand">
                                <h3 class="uk-card-title uk-margin-remove-bottom">Enquiry Form</h3>                               
                            </div>
                        </div>
                    </div>
                    <div class="uk-card-body">
                      <form>
                             <div class="uk-margin">
                                <div class="uk-inline">
                                    <span class="uk-form-icon" uk-icon="icon: user"></span>
                                    <input class="uk-input" placeholder="Name">
                                </div>
                             </div>
                               <div class="uk-margin">
                                <div class="uk-inline">
                                    <span class="uk-form-icon" uk-icon="icon: mail"></span>
                                    <input class="uk-input" placeholder="Email">
                                </div>
                             </div>
                               <div class="uk-margin">
                                <div class="uk-inline">
                                    <span class="uk-form-icon" uk-icon="icon: phone"></span>
                                    <input class="uk-input" placeholder="Mobile no.">
                                </div>
                             </div>
                               <div class="uk-margin">            
                                <textarea class="uk-input" placeholder="Message" row="6"></textarea>  
                             </div>
                                                    
                           </form>
                    </div>
                    <div class="uk-card-footer">
                        <a href="#" class="uk-button uk-button-danger">Send Message &nbsp;<i class="fa fa-send"></i></a>
                    </div>
                </div>
             </div>
        </div>
    </div>
</div>


 <!-- footer -->
<footer>
            <div class="container">
                <div class="row">
                    <div class="col-xl-3 col-lg-3 col-sm-3 col-12 footer_widget">
                        <h4>Exlore Links</h4>
                        <ul class="list-unstyled widget_list">
                            <li><a href="#">Home</a></li>
                            <li><a href="#">About us</a></li>
                            <li><a href="#">Contact us</a></li>
                        </ul>
                    </div>
                    <div class="col-xl-3 col-lg-3 col-sm-3 col-12 footer_widget">
                        <h4>  Industries</h4>
                        <ul class="list-unstyled widget_list">
                            <li>Engineering</li>
                            <li>Healthcare</li>
                            <li>Construction/Real Estate</li>
                            <li>Devops</li>
                            <li>Defence</li>
                            <li>Hotels & Hospitals</li>
                            <li>Banking</li>
                            <li>Legal</li>
                            <li>Travel</li>
                            <li>Education</li>
                            <li>IT</li>
                        </ul>
                    </div>                    
                    <div class="col-xl-3 col-lg-3 col-sm-3 col-12 footer_widget">
                        <h4>Information</h4>
                        <ul class="list-unstyled contact_widget">
                            <li>
                                <strong>Office Address</strong>
                                <a href="#">Blue Meadows CHS, C-1002, off JVLR,<br/>
                                behind Majas Bus depot, Jogeshwari East,
                                <br/>Mumbai-400060.
                                </a>
                            </li>
                            <li>
                                <strong>Contact enquiry</strong>
                                <a href="#">(+91) 9820731115</a>
                            </li>
                            <li>
                                <strong>Email us at</strong>
                                <a href="#">phenixlingualsolutions@gmail.com</a>
                            </li>
                             <li>
                                <strong>Hours of operation</strong>
                                <a href="#">10:00 am - 07:00 pm</a>
                            </li>
                        </ul>
                    </div>
                    <div class="col-xl-3 col-lg-3 col-sm-3 col-12 footer_widget">
                        <h4>Blog</h4>
                        <!--<ul class="list-unstyled widget_list">
                            <li><a href="#">Blog link one</a></li>
                            <li><a href="#">Blog link two</a></li>
                            <li><a href="#">Blog link three</a></li>
                            <li><a href="#">Blog link four</a></li>
                            <li><a href="#">Blog link five</a></li>
                            <li><a href="#">Blog link six</a></li>
                        </ul>-->
                    </div>
                </div>
            </div>
        </footer>

        <div class="bottom_footer">
            <div class="container">
                <div class="row">
                    <div class="col-xl-8">
                        <p class="d-inline-block">Copyright &copy 2019-20 <a href="#">Plstranslators</a>. All right reserved | <a href="#">Sitemap</a> | <a href="#">Terms & Conditions</a> | <a href="#">Privacy Policy</a></p>
                       
                    </div>
                    <div class="col-xl-4 float-right">
                        <ul class="list-inline">
                            <li class="list-inline-item"><a href="#"><img src="images/facebook.png" alt="facebook"></a></li>
                            <li class="list-inline-item"><a href="#"><img src="images/f_twitter.png" alt="facebook"></a></li>
                            <li class="list-inline-item"><a href="#"><img src="images/f_linkedin.png" alt="facebook"></a></li>
                            <li class="list-inline-item"><a href="#"><img src="images/f_instagram.png" alt="facebook"></a></li>
                            <li class="list-inline-item"><a href="#"><img src="images/f_youtube.png" alt="facebook"></a></li>                          
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    <!-- jqueries -->
    <script src="js/jquery-3.2.1.slim.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/uikit.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/uikit-icons.min.js"></script>
    <script src="js/script.js"></script>
	
	